/* =============================================
   GUESS THE CRICKET SCORE — script.js
   All game logic, scoring, and local storage.
   ============================================= */

/* ── 1. CONSTANTS & CONFIG ──────────────── */

// Difficulty settings: min and max score range
const DIFFICULTY = {
  easy:   { label: 'EASY',   min: 50,  max: 150 },
  medium: { label: 'MEDIUM', min: 80,  max: 250 },
  hard:   { label: 'HARD',   min: 100, max: 350 },
};

// Points awarded based on how close the guess is
const SCORING_RULES = [
  { maxDiff: 0,  points: 100, emoji: '🎯', title: 'Century Prediction!',  message: 'Unbelievable! You nailed it exactly!' },
  { maxDiff: 5,  points: 80,  emoji: '🏏', title: 'Almost a Boundary!',   message: 'Outstanding accuracy — nearly there!' },
  { maxDiff: 10, points: 60,  emoji: '🙌', title: 'Six in the Stands!',   message: 'A solid prediction. Great cricketing instinct!' },
  { maxDiff: 20, points: 40,  emoji: '👏', title: 'Decent Drive!',        message: 'Not bad — keep practicing your guesses.' },
  { maxDiff: Infinity, points: 0, emoji: '🦆', title: 'Duck!', message: 'Better Luck Next Time! The scoreboard fooled you.' },
];

const LS_LEADERBOARD = 'cricketScoreLeaderboard'; // localStorage key
const MAX_LEADERBOARD = 10;                        // max entries to keep


/* ── 2. STATE ───────────────────────────── */

let state = {
  difficulty: 'easy',   // current difficulty key
  actualScore: 0,        // randomly generated score
  totalPoints: 0,        // cumulative points this session
  round: 1,              // current round number
  lastPoints: 0,         // points from last round (for leaderboard save)
};


/* ── 3. DOM REFERENCES ──────────────────── */

// Screens
const screens = {
  home:        document.getElementById('screen-home'),
  game:        document.getElementById('screen-game'),
  result:      document.getElementById('screen-result'),
  leaderboard: document.getElementById('screen-leaderboard'),
};

// Home
const diffButtons        = document.querySelectorAll('.diff-btn');
const btnStart           = document.getElementById('btn-start');
const bestScoreBanner    = document.getElementById('best-score-banner');
const bestScoreDisplay   = document.getElementById('best-score-display');

// Game HUD
const hudTotal           = document.getElementById('hud-total');
const hudRound           = document.getElementById('hud-round');
const hudDiffBadge       = document.getElementById('hud-diff-badge');
const rangeText          = document.getElementById('range-text');

// Game inputs
const guessInput         = document.getElementById('guess-input');
const btnSubmit          = document.getElementById('btn-submit');
const inputError         = document.getElementById('input-error');
const btnResetGame       = document.getElementById('btn-reset-game');

// Result
const resultEmoji        = document.getElementById('result-emoji');
const resultTitle        = document.getElementById('result-title');
const resultMessage      = document.getElementById('result-message');
const resGuess           = document.getElementById('res-guess');
const resActual          = document.getElementById('res-actual');
const resDiff            = document.getElementById('res-diff');
const resPoints          = document.getElementById('res-points');
const resTotal           = document.getElementById('res-total');
const btnPlayAgain       = document.getElementById('btn-play-again');
const btnLeaderboard     = document.getElementById('btn-leaderboard');
const btnHome            = document.getElementById('btn-home');

// Leaderboard
const lbList             = document.getElementById('lb-list');
const btnLbSave          = document.getElementById('btn-lb-save');
const btnLbBack          = document.getElementById('btn-lb-back');

// Modal
const modalName          = document.getElementById('modal-name');
const playerNameInput    = document.getElementById('player-name-input');
const btnSaveConfirm     = document.getElementById('btn-save-confirm');
const btnSaveCancel      = document.getElementById('btn-save-cancel');


/* ── 4. SCREEN NAVIGATION ───────────────── */

/**
 * showScreen(name)
 * Hides all screens and shows the one matching `name`.
 */
function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.remove('active'));
  screens[name].classList.add('active');
}


/* ── 5. HOME SCREEN LOGIC ───────────────── */

/** Update difficulty button styling when clicked */
diffButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    diffButtons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.difficulty = btn.dataset.diff;
  });
});

/** Show best score on home screen from localStorage */
function updateBestScoreBanner() {
  const board = loadLeaderboard();
  if (board.length > 0) {
    const best = board[0].score;
    bestScoreDisplay.textContent = best;
    bestScoreBanner.classList.remove('hidden');
  } else {
    bestScoreBanner.classList.add('hidden');
  }
}

/** Start game button */
btnStart.addEventListener('click', () => {
  startNewRound(true); // true = reset total points
  showScreen('game');
});


/* ── 6. GAME LOGIC ──────────────────────── */

/**
 * generateScore()
 * Returns a random integer between min and max (inclusive)
 * based on the current difficulty.
 */
function generateScore() {
  const { min, max } = DIFFICULTY[state.difficulty];
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * startNewRound(resetTotal)
 * Generates a new target score and updates the HUD.
 * Pass resetTotal=true when beginning a fresh game.
 */
function startNewRound(resetTotal = false) {
  if (resetTotal) {
    state.totalPoints = 0;
    state.round = 1;
  }

  state.actualScore = generateScore();

  // Update HUD
  const diff = DIFFICULTY[state.difficulty];
  hudDiffBadge.textContent = diff.label;
  rangeText.textContent    = `${diff.min} – ${diff.max}`;
  hudTotal.textContent     = state.totalPoints;
  hudRound.textContent     = state.round;

  // Reset input
  guessInput.value = '';
  inputError.classList.add('hidden');
  guessInput.focus();

  // Accessibility: keep input min/max in sync with difficulty
  guessInput.min = diff.min - 50; // allow a wide range so users can explore
  guessInput.max = diff.max + 100;
}

/** Submit guess button — also triggered by Enter key */
btnSubmit.addEventListener('click', submitGuess);
guessInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') submitGuess();
});

/**
 * submitGuess()
 * Validates input, calculates the result, and shows the result screen.
 */
function submitGuess() {
  const raw = guessInput.value.trim();

  // Validate: must be a non-empty positive integer
  if (raw === '' || isNaN(raw) || Number(raw) < 0 || !Number.isInteger(Number(raw))) {
    inputError.classList.remove('hidden');
    guessInput.focus();
    return;
  }

  inputError.classList.add('hidden');

  const guess = parseInt(raw, 10);
  const diff  = Math.abs(guess - state.actualScore);
  const rule  = getScoringRule(diff);

  // Add points
  state.totalPoints += rule.points;
  state.lastPoints   = state.totalPoints; // snapshot for leaderboard

  showResult(guess, diff, rule);
}

/**
 * getScoringRule(diff)
 * Returns the first scoring rule where diff <= maxDiff.
 */
function getScoringRule(diff) {
  return SCORING_RULES.find(r => diff <= r.maxDiff);
}

/** Reset game back to round 1 with zero points */
btnResetGame.addEventListener('click', () => {
  if (confirm('Reset the game? Your current score will be lost.')) {
    startNewRound(true);
  }
});


/* ── 7. RESULT SCREEN LOGIC ─────────────── */

/**
 * showResult(guess, diff, rule)
 * Populates and displays the result screen.
 */
function showResult(guess, diff, rule) {
  resultEmoji.textContent   = rule.emoji;
  resultTitle.textContent   = rule.title;
  resultMessage.textContent = rule.message;

  resGuess.textContent  = guess;
  resActual.textContent = state.actualScore;
  resDiff.textContent   = diff;
  resPoints.textContent = rule.points;
  resTotal.textContent  = `${state.totalPoints} pts`;

  showScreen('result');
}

/** Play Again: next round, same session */
btnPlayAgain.addEventListener('click', () => {
  state.round++;
  startNewRound(false);
  showScreen('game');
});

/** Home: go back to home, refresh best score */
btnHome.addEventListener('click', () => {
  updateBestScoreBanner();
  showScreen('home');
});

/** Leaderboard: show leaderboard from result screen */
btnLeaderboard.addEventListener('click', () => {
  renderLeaderboard();
  showScreen('leaderboard');
});


/* ── 8. LEADERBOARD ─────────────────────── */

/**
 * loadLeaderboard()
 * Reads the leaderboard array from localStorage.
 * Returns an empty array if nothing is saved.
 */
function loadLeaderboard() {
  try {
    return JSON.parse(localStorage.getItem(LS_LEADERBOARD)) || [];
  } catch {
    return [];
  }
}

/**
 * saveLeaderboard(board)
 * Writes the leaderboard array to localStorage.
 */
function saveLeaderboard(board) {
  localStorage.setItem(LS_LEADERBOARD, JSON.stringify(board));
}

/**
 * addLeaderboardEntry(name, score, difficulty)
 * Adds a new entry, sorts by score descending,
 * trims to MAX_LEADERBOARD entries, and saves.
 */
function addLeaderboardEntry(name, score, difficulty) {
  const board = loadLeaderboard();
  board.push({ name, score, difficulty, date: new Date().toLocaleDateString() });
  board.sort((a, b) => b.score - a.score);
  board.splice(MAX_LEADERBOARD); // keep only top entries
  saveLeaderboard(board);
}

/**
 * renderLeaderboard()
 * Builds and injects leaderboard HTML into the list container.
 */
function renderLeaderboard() {
  const board = loadLeaderboard();

  if (board.length === 0) {
    lbList.innerHTML = '<p class="lb-empty">No scores yet. Play a game and save your score!</p>';
    return;
  }

  // Build rank-ordered entries
  lbList.innerHTML = board.map((entry, i) => {
    const rankClass = i === 0 ? 'top-1' : i === 1 ? 'top-2' : i === 2 ? 'top-3' : '';
    const medal     = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;
    return `
      <div class="lb-entry ${rankClass}">
        <span class="lb-rank">${medal}</span>
        <span class="lb-name">${escapeHtml(entry.name)}</span>
        <span class="lb-diff-badge lb-diff-${entry.difficulty}">${entry.difficulty.toUpperCase()}</span>
        <span class="lb-score">${entry.score} pts</span>
      </div>
    `;
  }).join('');
}

/** Escape HTML to prevent XSS from user-entered names */
function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/** Save score button — opens name input modal */
btnLbSave.addEventListener('click', () => {
  playerNameInput.value = '';
  modalName.classList.remove('hidden');
  playerNameInput.focus();
});

/** Confirm save in modal */
btnSaveConfirm.addEventListener('click', confirmSave);
playerNameInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') confirmSave();
});

function confirmSave() {
  const name = playerNameInput.value.trim();
  if (!name) {
    playerNameInput.focus();
    return;
  }
  addLeaderboardEntry(name, state.lastPoints, state.difficulty);
  modalName.classList.add('hidden');
  renderLeaderboard();             // refresh the list
  btnLbSave.disabled = true;       // prevent double-saving
  btnLbSave.textContent = '✅ Saved!';
}

/** Cancel save */
btnSaveCancel.addEventListener('click', () => {
  modalName.classList.add('hidden');
});

/** Back from leaderboard → result screen */
btnLbBack.addEventListener('click', () => {
  showScreen('result');
});


/* ── 9. INIT ────────────────────────────── */

/**
 * init()
 * Called once on page load.
 * Sets up the default state and shows the home screen.
 */
function init() {
  updateBestScoreBanner();
  showScreen('home');
}

init();
